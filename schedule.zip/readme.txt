=== Schedule ===
Contributors: scheduler
Tags: schedule, demo, calls
Requires at least: 3.0.1
Tested up to: 5.2.2
Requires PHP: 5.6
Stable tag: 4.3
Text Domain: schedule
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Plugin for scheduling demos or calls

== Description ==

The easiest way to install a button in your post and pages offering to your customers to request a demo or a call

== Installation ==

1. Download therapist plugin
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= How can I configure the plugin? =

In the settings sections you will see "Schedule configuration" link.

== Changelog ==

= 1.0 =
* Link button and configuration